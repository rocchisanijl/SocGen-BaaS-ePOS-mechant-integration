<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

include_once __DIR__ . '/vendor/autoload.php';

use ConfigurationCore as Configuration;
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;
use PrestaShop\PrestaShop\Core\File\FileUploader as Fileuploader;

class Societegeneralepayment extends PaymentModule
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'societegeneralepayment';
        $this->tab = 'payments_gateways';
        $this->version = '1.1.0';
        $this->author = 'Société générale';
        $this->need_instance = 0;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Flow Smart Credit solution de financement par société générale');
        $this->description = $this->l('Module paiement pour société générale');

        $this->limited_currencies = array('EUR');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        if (extension_loaded('curl') == false) {
            $this->_errors[] = $this->l('You have to enable the cURL extension on your server to install this module');
            return false;
        }

        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MODE', '0');
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X', 100);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X_F', 100);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X', 300);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X_F', 300);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_REVOLVINGPOS', 300);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X', 3000);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X_F', 3000);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X', 4000);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X_F', 4000);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_REVOLVINGPOS', 3000);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_FRF_3X', 1);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_FRF_3X_F', 1);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_FRF_4X', 1);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_FRF_4X_F', 1);
        Configuration::updateValue('SOCIETEGENERALEPAYMENT_REVOLVINGPOS', 1);

        return parent::install() && $this->installTab() &&
            $this->registerHook('header') &&
            $this->registerHook('backOfficeHeader') &&
            $this->registerHook('payment') &&
            $this->registerHook('paymentReturn') &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('actionPaymentCCAdd') &&
            $this->registerHook('actionPaymentConfirmation') &&
            $this->registerHook('displayPayment') &&
            $this->registerHook('displayPaymentReturn') &&
            $this->registerHook('displayPaymentTop') &&
            $this->registerHook('displayPaymentByBinaries');
    }

    public function uninstall()
    {
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MODE');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X_F');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X_F');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_REVOLVINGPOS');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X_F');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X_F');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_REVOLVINGPOS');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_FRF_3X');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_FRF_3X_F');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_FRF_4X');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_FRF_4X_F');
        Configuration::deleteByName('SOCIETEGENERALEPAYMENT_REVOLVINGPOS');

        return parent::uninstall() && $this->uninstallTab() &&
            $this->unregisterHook('header') &&
            $this->unregisterHook('backOfficeHeader') &&
            $this->unregisterHook('payment') &&
            $this->unregisterHook('paymentReturn') &&
            $this->unregisterHook('paymentOptions') &&
            $this->unregisterHook('actionPaymentCCAdd') &&
            $this->unregisterHook('actionPaymentConfirmation') &&
            $this->unregisterHook('displayPayment') &&
            $this->unregisterHook('displayPaymentReturn') &&
            $this->unregisterHook('displayPaymentTop') &&
            $this->unregisterHook('displayPaymentByBinaries');
    }

    public function installTab()
    {
        $tab = new Tab();
        $tab->active = true;
        $tab->enabled = false;
        $tab->class_name = 'AdminCheckapi';
        $tab->name = [];
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'Check API';
        }

        $tab->id_parent = null;
        $tab->module = $this->name;

        return $tab->add();
    }

    public function uninstallTab()
    {
        $id_tab = (int)Tab::getIdFromClassName('AdminCheckapi');
        if ($id_tab) {
            $tab = new Tab($id_tab);

            return $tab->delete();
        }

        return false;
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitSocietegeneralepaymentModule')) == true) {
            $this->postProcess();
        }

        Media::addJsDef([
            'sgAjaxToken' => Tools::getAdminTokenLite('AdminCheckapi'),
        ]);

        $this->context->smarty->assign('module_dir', $this->_path);
        $this->context->smarty->assign('PUBKEY', Configuration::get('SOCIETEGENERALEPAYMENT_PUBKEY'));
        $this->context->smarty->assign('PRIVKEY', Configuration::get('SOCIETEGENERALEPAYMENT_PRIVKEY'));

        $output = $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configure.tpl');

        return $output . $this->renderForm();
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitSocietegeneralepaymentModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(
                    [
                        'type' => 'switch',
                        'prefix' => '<i class="icon icon-list"></i>',
                        'label' => $this->l('Mode'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MODE',
                        'desc' => $this->l('Development or production mode.'),
                        'invalid_message' => $this->l('Entrez une valeur'),
                        'is_bool' => true,
                        'values' => array(
                            array(
                                'id' => 'production',
                                'value' => true,
                                'label' => $this->l('Production')
                            ),
                            array(
                                'id' => 'development',
                                'value' => false,
                                'label' => $this->l('Development')
                            )
                        ),
                    ],
                    array(
                        'type' => 'password',
                        'label' => $this->l('Clé public'),
                        'name' => 'SOCIETEGENERALEPAYMENT_PUBKEY',
                        'desc' => $this->l('Votre clé public fourni par votre banque'),
                        'required' => true
                    ),
                    array(
                        'type' => 'password',
                        'label' => $this->l('Clé privée'),
                        'name' => 'SOCIETEGENERALEPAYMENT_PRIVKEY',
                        'desc' => $this->l('Votre clé privée fourni par votre banque'),
                        'required' => true
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Mode de paiement 3X sans frais'),
                        'name' => 'SOCIETEGENERALEPAYMENT_FRF_3X',
                        'desc' => $this->l('Activer la méthode de paiement en 3 fois sans frais'),
                        'values' => [
                            [
                                'id' => 'is_3x_on',
                                'value' => 1,
                                'label' => $this->l('Oui'),
                            ],
                            [
                                'id' => 'is_3x_off',
                                'value' => 0,
                                'label' => $this->l('Non'),
                            ],
                        ],
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant minimum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X',
                        'desc' => $this->l('Montant minimum pour afficher l\'option de paiement pour le mode 3X sans frais.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant maximum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X',
                        'desc' => $this->l('Montant maximum pour afficher l\'option de paiement pour le mode 3X sans frais.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Mode de paiement 3X avec frais'),
                        'name' => 'SOCIETEGENERALEPAYMENT_FRF_3X_F',
                        'desc' => $this->l('Activer la méthode de paiement en 3 fois avec frais'),
                        'values' => [
                            [
                                'id' => 'is_3x_f_on',
                                'value' => 1,
                                'label' => $this->l('Oui'),
                            ],
                            [
                                'id' => 'is_3x_f_off',
                                'value' => 0,
                                'label' => $this->l('Non'),
                            ],
                        ],
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant minimum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X_F',
                        'desc' => $this->l('Montant minimum pour afficher l\'option de paiement pour le mode 3X avec frais.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant maximum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X_F',
                        'desc' => $this->l('Montant maximum pour afficher l\'option de paiement pour le mode 3X avec frais.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Mode de paiement 4X sans frais'),
                        'name' => 'SOCIETEGENERALEPAYMENT_FRF_4X',
                        'desc' => $this->l('Activer la méthode de paiement en 4 fois sans frais'),
                        'values' => [
                            [
                                'id' => 'is_4x_on',
                                'value' => 1,
                                'label' => $this->l('Oui'),
                            ],
                            [
                                'id' => 'is_4x_off',
                                'value' => 0,
                                'label' => $this->l('Non'),
                            ],
                        ],
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant minimum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X',
                        'desc' => $this->l('Montant minimum pour afficher l\'option de paiement pour le mode 4X sans frais.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant maximum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X',
                        'desc' => $this->l('Montant maximum pour afficher l\'option de paiement pour le mode 4X sans frais.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Mode de paiement 4X avec frais'),
                        'name' => 'SOCIETEGENERALEPAYMENT_FRF_4X_F',
                        'desc' => $this->l('Activer la méthode de paiement en 4 fois avec frais'),
                        'values' => [
                            [
                                'id' => 'is_4x_f_on',
                                'value' => 1,
                                'label' => $this->l('Oui'),
                            ],
                            [
                                'id' => 'is_4x_f_off',
                                'value' => 0,
                                'label' => $this->l('Non'),
                            ],
                        ],
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant minimum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X_F',
                        'desc' => $this->l('Montant minimum pour afficher l\'option de paiement pour le mode 4X avec frais.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant maximum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X_F',
                        'desc' => $this->l('Montant maximum pour afficher l\'option de paiement pour le mode 4X avec frais.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Mode Revolving Pos.'),
                        'name' => 'SOCIETEGENERALEPAYMENT_REVOLVINGPOS',
                        'desc' => $this->l('Activer la méthode de paiement pour l\'Allemagne.'),
                        'values' => [
                            [
                                'id' => 'is_revpos_on',
                                'value' => 1,
                                'label' => $this->l('Oui'),
                            ],
                            [
                                'id' => 'is_revpos_off',
                                'value' => 0,
                                'label' => $this->l('Non'),
                            ],
                        ],
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant minimum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_REVOLVINGPOS',
                        'desc' => $this->l('Montant minimum pour afficher l\'option de paiement pour le mode REVOLVINGPOS.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                    array(
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-euro"></i>',
                        'label' => $this->l('Montant maximum de commande'),
                        'name' => 'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_REVOLVINGPOS',
                        'desc' => $this->l('Montant maximum pour afficher l\'option de paiement pour le mode REVOLVINGPOS.'),
                        'required' => true,
                        'invalid_message' => $this->l('Please enter a positive value'),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'SOCIETEGENERALEPAYMENT_MODE' => Configuration::get('SOCIETEGENERALEPAYMENT_MODE', null),
            'SOCIETEGENERALEPAYMENT_FRF_3X' => Configuration::get('SOCIETEGENERALEPAYMENT_FRF_3X', null),
            'SOCIETEGENERALEPAYMENT_FRF_4X' => Configuration::get('SOCIETEGENERALEPAYMENT_FRF_4X', null),
            'SOCIETEGENERALEPAYMENT_FRF_3X_F' => Configuration::get('SOCIETEGENERALEPAYMENT_FRF_3X_F', null),
            'SOCIETEGENERALEPAYMENT_FRF_4X_F' => Configuration::get('SOCIETEGENERALEPAYMENT_FRF_4X_F', null),
            'SOCIETEGENERALEPAYMENT_REVOLVINGPOS' => Configuration::get('SOCIETEGENERALEPAYMENT_REVOLVINGPOS', null),
            'SOCIETEGENERALEPAYMENT_PRIVKEY' => Configuration::get('SOCIETEGENERALEPAYMENT_PRIVKEY', null),
            'SOCIETEGENERALEPAYMENT_PUBKEY' => Configuration::get('SOCIETEGENERALEPAYMENT_PUBKEY', null),
            'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X' => Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X', null),
            'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X' => Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X', null),
            'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X_F' => Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X_F', null),
            'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X_F' => Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X_F', null),
            'SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_REVOLVINGPOS' => Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_REVOLVINGPOS', null),
            'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X' => Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X', null),
            'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X' => Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X', null),
            'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X_F' => Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X_F', null),
            'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X_F' => Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X_F', null),
            'SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_REVOLVINGPOS' => Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_REVOLVINGPOS', null),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();
        foreach (array_keys($form_values) as $key) {
            if ($key === 'SOCIETEGENERALEPAYMENT_PRIVKEY' || $key === 'SOCIETEGENERALEPAYMENT_PUBKEY') {
                if (Tools::getValue($key) !== Configuration::get($key)) {
                    $this->context->cookie->__set('sg_access_token', null);
                    $this->context->cookie->__set('sg_access_token_time', null);
                    $this->context->cookie->write();
                }
            }
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be loaded in the BO.
     */
    public function hookBackOfficeHeader()
    {
        $this->context->controller->addJS($this->_path . 'views/js/back.js');
        $this->context->controller->addCSS($this->_path . 'views/css/back.css');
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
        $this->context->controller->addJS($this->_path . '/views/js/front.js');
        $this->context->controller->addCSS($this->_path . '/views/css/front.css');
    }

    /**
     * This method is used to render the payment button,
     * Take care if the button should be displayed or not.
     */
    public function hookPayment($params)
    {
        if ($this->active == false)
            return;

        $currency_id = $params['cart']->id_currency;
        $currency = new Currency((int)$currency_id);

        if (in_array($currency->iso_code, $this->limited_currencies) == false)
            return false;

        $this->smarty->assign('module_dir', $this->_path);

        return $this->display(__FILE__, 'views/templates/hook/payment.tpl');
    }

    /**
     * This hook is used to display the order confirmation page.
     */
    public function hookPaymentReturn($params)
    {
        if ($this->active == false)
            return;

        $order = $params['order'];

        if ($order->getCurrentOrderState()->id != Configuration::get('PS_OS_ERROR'))
            $this->smarty->assign('status', 'ok');

        $this->smarty->assign(array(
            'id_order' => $order->id,
            'reference' => $order->reference,
            'params' => $params,
            'total' => Tools::displayPrice($order->total_paid, Context::getContext()->currency, false),
        ));

        return $this->display(__FILE__, 'views/templates/hook/confirmation.tpl');
    }

    public function hookDisplayPaymentByBinaries()
    {
        $this->smarty->assign('module_dir', $this->_path);
        return $this->display(__FILE__, 'views/templates/hook/logo.tpl');
    }

    /**
     * Return payment options available for PS 1.7+
     *
     * @param array Hook parameters
     *
     * @return array|null
     */
    public function hookPaymentOptions($params)
    {
        $bearer = $this->context->cookie->__get('sg_access_token');
        $token_expires = $this->context->cookie->__get('sg_access_token_time');

        if (!$this->active || $this->active && (
                '' === Configuration::get('SOCIETEGENERALEPAYMENT_PUBKEY') ||
                null === Configuration::get('SOCIETEGENERALEPAYMENT_PUBKEY') ||
                '' === Configuration::get('SOCIETEGENERALEPAYMENT_PRIVKEY') ||
                null === Configuration::get('SOCIETEGENERALEPAYMENT_PRIVKEY')
            )) {
            return null;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return null;
        }

        if (false == $bearer || time() > (int)$token_expires) {
            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://sso.sgmarkets.com/sgconnect/oauth2/access_token?grant_type=client_credentials&scope=openid',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/x-www-form-urlencoded',
                    'Authorization: Basic ' . base64_encode(Configuration::get('SOCIETEGENERALEPAYMENT_PUBKEY') . ':' . Configuration::get('SOCIETEGENERALEPAYMENT_PRIVKEY')),
                ),
            ));

            $response = json_decode(curl_exec($curl));

            curl_close($curl);

            $bearer = $response->access_token;
            $this->context->cookie->__set('sg_access_token', $response->access_token);
            $this->context->cookie->__set('sg_access_token_time', time() + $response->expires_in);
            $this->context->cookie->setExpire(time() + $response->expires_in);
            $this->context->cookie->write();
        }

        $cart_id = Context::getContext()->cart->id;
        $cart = Context::getContext()->cart = new Cart((int)$cart_id);
        $amount = (float)$cart->getOrderTotal(true, Cart::BOTH);
        $billingAddress = new Address((int)$cart->id_address_invoice);
        $billingCountry = new Country((int)$billingAddress->id_country);

        if (Configuration::get('SOCIETEGENERALEPAYMENT_PRIVKEY') !== null && Configuration::get('SOCIETEGENERALEPAYMENT_PRIVKEY') !== '' && isset($bearer)) {
            if ('FR' === $billingCountry->iso_code
                && '1' === Configuration::get('SOCIETEGENERALEPAYMENT_FRF_3X')
                && (double)$amount >= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X')
                && (double)$amount <= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X')
            ) {
                $option = new PaymentOption();
                $option->setCallToActionText($this->l('Payer en 3 fois sans frais par carte bancaire avec Flow'))
                    ->setAction($this->context->link->getModuleLink($this->name, 'validation', array('mean' => 'FRF_3X'), true));
                $options[] = $option;
            }

            if ('FR' === $billingCountry->iso_code
                && '1' === Configuration::get('SOCIETEGENERALEPAYMENT_FRF_3X_F')
                && (double)$amount >= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_3X_F')
                && (double)$amount <= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_3X_F')
            ) {
                $option = new PaymentOption();
                $option->setCallToActionText($this->l('Payer en 3 fois par carte bancaire avec Flow'))
                    ->setAction($this->context->link->getModuleLink($this->name, 'validation', array('mean' => 'FRF_3X_F'), true));
                $options[] = $option;
            }

            if ('FR' === $billingCountry->iso_code
                && '1' === Configuration::get('SOCIETEGENERALEPAYMENT_FRF_4X')
                && (double)$amount >= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X')
                && (double)$amount <= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X')
            ) {
                $option = new PaymentOption();
                $option->setCallToActionText($this->l('Payer en 4 fois sans frais par carte bancaire avec Flow'))
                    ->setAction($this->context->link->getModuleLink($this->name, 'validation', array('mean' => 'FRF_4X'), true));
                $options[] = $option;
            }

            if ('FR' === $billingCountry->iso_code
                && '1' === Configuration::get('SOCIETEGENERALEPAYMENT_FRF_4X_F')
                && (double)$amount >= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_4X_F')
                && (double)$amount <= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_4X_F')
            ) {
                $option = new PaymentOption();
                $option->setCallToActionText($this->l('Payer en 4 fois par carte bancaire avec Flow'))
                    ->setAction($this->context->link->getModuleLink($this->name, 'validation', array('mean' => 'FRF_4X_F'), true));
                $options[] = $option;
            }

            if ('DE' === $billingCountry->iso_code
                && '1' === Configuration::get('SOCIETEGENERALEPAYMENT_REVOLVINGPOS')
                && (double)$amount >= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MIN_ORDER_AMOUNT_REVOLVINGPOS')
                && (double)$amount <= (double)Configuration::get('SOCIETEGENERALEPAYMENT_MAX_ORDER_AMOUNT_REVOLVINGPOS')
            ) {
                $option = new PaymentOption();
                $option->setCallToActionText($this->l('Payer par crédit'))
                    ->setAction($this->context->link->getModuleLink($this->name, 'validation', array('mean' => 'REVOLVINGPOS'), true));
                $options[] = $option;
            }
        }

        return $options;
    }

    /**
     * @param Cart $cart
     *
     * @return string
     *
     * @throws Exception
     */
    public function renderModal(Cart $cart)
    {
        return $this->fetch('module:societegeneralepayment/modal.tpl');
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);
        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    public function hookActionValidateOrder($params)
    {
        if ($this->active == false)
            return;

        $order = $params['order'];

        $result = explode("|", Tools::getValue('Data'));
        $datas = [];
        foreach ($result as $data) {
            $explode = explode('=', $data);
            $datas[$explode[0]] = $explode[1];
        }

        $sql = 'UPDATE ' . _DB_PREFIX_ . 'order_payment SET transaction_id="' . pSQL($datas['transactionReference']) . '" WHERE order_reference="' . pSQL($order->reference) . '"';
        Db::getInstance()->execute($sql);
    }
}
