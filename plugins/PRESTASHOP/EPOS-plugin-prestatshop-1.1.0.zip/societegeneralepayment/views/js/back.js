'use strict';

(function($) {
    $(document).ready(function() {
        $('#check_api_working').on('click', function() {
            let $that = $(this);

            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: 'index.php',
                data: {
                    controller: 'AdminCheckapi',
                    ajax: 1,
                    token: sgAjaxToken,
                    action: 'checkapi'
                }
            }).fail(function (jqXHR, textStatus) {
            }).done(function (result) {
                if(true === result.success) {
                    $that.parent().parent().removeClass('alert-default');
                    $that.parent().parent().removeClass('alert-danger');
                    $that.parent().parent().addClass('alert-success');
                    $('.api-error-message').html('<b style="color:green;">Connexion effectuée avec succès !</b></span>')
                } else {
                    $that.parent().parent().removeClass('alert-default');
                    $that.parent().parent().removeClass('alert-success');
                    $that.parent().parent().addClass('alert-danger');
                    $('.api-error-message').html('<b style="color:red;">Une erreur est survenue : vérifiez votre clé privée et publique.</b></span>')
                }
            }).always(function (data) {
            });
        })
    });
})(jQuery);