<?php

class AdminCheckapiController extends ModuleAdminController
{
    public function ajaxProcessCheckapi()
    {
        $datas['success'] = false;

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://sso.sgmarkets.com/sgconnect/oauth2/access_token?grant_type=client_credentials&scope=openid',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded',
                'Authorization: Basic ' . base64_encode(Configuration::get('SOCIETEGENERALEPAYMENT_PUBKEY') . ':' . Configuration::get('SOCIETEGENERALEPAYMENT_PRIVKEY')),
            ),
        ));

        $response = json_decode(curl_exec($curl));

        curl_close($curl);

        if(isset($response->access_token)) {
            $datas['success'] = true;
        }
        if(isset($response->error)) {
            $datas['success'] = false;
        }

        if ($this->ajax) {
            header('Content-Type: application/json');
            $this->ajaxDie(json_encode($datas));
        }
    }
}