<?php

/**
 * 2022 Websource
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    Websource <jonathan@websource.fr>
 * @copyright 2022 Websource
 */
class SocietegeneralepaymentValidationModuleFrontController extends ModuleFrontController
{
    protected $apiUrl;

    public function __construct()
    {
        $this->apiUrl = 'https://apimgm-socgenepos-uat.azure-api.net';
        if ('1' === Configuration::get('SOCIETEGENERALEPAYMENT_MODE')) {
            $this->apiUrl = 'https://apimgm-socgenepos-prod.azure-api.net';
        }
        parent::__construct();
    }

    /**
     * This class should be use by your Instant Payment
     * Notification system to validate the order remotely
     */
    public function postProcess()
    {
        /*
         * If the module is not active anymore, no need to process anything.
         */
        if ($this->module->active == false) {
            die;
        }

        /**
         * Since it is an example, we choose sample data,
         * You'll have to get the correct values :)
         */
        $cart_id = Context::getContext()->cart->id;
        $cart = new Cart((int)$cart_id);
        $id_customer = Context::getContext()->cart->id_customer;
        $amount = (float)$cart->getOrderTotal(true, Cart::BOTH);
        $customer = new Customer((int)$id_customer);
        $civility = new Gender((int)$customer->id_gender);
        $civilityName = 'Mr.';
        if ('M' !== $civility->name[Context::getContext()->language->id]) {
            $civilityName = 'Mme.';
        }
        $shippingAddress = new Address((int)$cart->id_address_delivery);
        $billingAddress = new Address((int)$cart->id_address_invoice);
        $billingStateDelivery = new State((int)$billingAddress->id_state);
        $shippingStateDelivery = new State((int)$shippingAddress->id_state);
        $billingCountry = new Country((int)$billingAddress->id_country);
        $shippingCountry = new Country((int)$shippingAddress->id_country);

        /*
         * Restore the context from the $cart_id & the $id_customer to process the validation properly.
         */
        $context = Context::getContext();
        $context->cart = new Cart((int)$cart_id);
        $context->customer = new Customer((int)$id_customer);
        $context->currency = new Currency((int)Context::getContext()->cart->id_currency);
        $context->language = new Language((int)Context::getContext()->customer->id_lang);

        $curl = curl_init();

        $bearer = $this->context->cookie->__get('sg_access_token');
        $token_expires = $this->context->cookie->__get('sg_access_token_time');

        if (false === $token_expires || time() > (int)$token_expires) {
            $this->context->cookie->__set('sg_access_token', null);
            $this->context->cookie->__set('sg_access_token_time', null);
            Tools::redirect('index.php?controller=cart&action=show');
        }

        $products = $cart->getProducts(true);

        if ([] === $products) {
            Tools::redirect('index.php?controller=cart&action=show');
        }

        $totalQty = 0;
        foreach ($products as $product) {
            $totalQty += $product['quantity'];
        }

        $paymentMean = Tools::getValue('mean');

        $billingAddressPhone = '+33666666666';
        if ('REVOLVINGPOS' === $paymentMean) {
            $billingAddressPhone = '+49666666666';
        }
        $billingAddressPhoneMobile = '+33666666666';
        if ('REVOLVINGPOS' === $paymentMean) {
            $billingAddressPhoneMobile = '+49666666666';
        }
        $shippingAddressPhone = '+33666666666';
        if ('REVOLVINGPOS' === $paymentMean) {
            $shippingAddressPhone = '+49666666666';
        }
        $shippingAddressPhoneMobile = '+33666666666';
        if ('REVOLVINGPOS' === $paymentMean) {
            $shippingAddressPhoneMobile = '+49666666666';
        }

        if ('' !== $billingAddress->phone) {
            $billingAddressPhone = '+33' . substr(Tools::replaceAccentedChars($billingAddress->phone), 1);
            if ('REVOLVINGPOS' === $paymentMean) {
                $billingAddressPhone = '+49' . substr(Tools::replaceAccentedChars($billingAddress->phone), 1);
                if('+49666666666' === $billingAddressPhoneMobile) {
                    $billingAddressPhoneMobile = $billingAddressPhone;
                }
            }
            if('+33666666666' === $billingAddressPhoneMobile) {
                $billingAddressPhoneMobile = $billingAddressPhone;
            }
        }
        if ('' !== $billingAddress->phone_mobile) {
            $billingAddressPhoneMobile = '+33' . substr(Tools::replaceAccentedChars($billingAddress->phone_mobile), 1);
            if ('REVOLVINGPOS' === $paymentMean) {
                $billingAddressPhoneMobile = '+49' . substr(Tools::replaceAccentedChars($billingAddress->phone_mobile), 1);
                if('+49666666666' === $billingAddressPhoneMobile) {
                    $billingAddressPhoneMobile = $billingAddressPhone;
                }
            }
            if('+33666666666' === $billingAddressPhoneMobile) {
                $billingAddressPhoneMobile = $billingAddressPhone;
            }
        }
        if ('' !== $shippingAddress->phone) {
            $shippingAddressPhone = '+33' . substr(Tools::replaceAccentedChars($shippingAddress->phone), 1);
            if ('REVOLVINGPOS' === $paymentMean) {
                $billingAddressPhone = '+49' . substr(Tools::replaceAccentedChars($shippingAddress->phone), 1);
                if('+49666666666' === $billingAddressPhoneMobile) {
                    $billingAddressPhoneMobile = $billingAddressPhone;
                }
            }
            if('+33666666666' === $billingAddressPhoneMobile) {
                $billingAddressPhoneMobile = $billingAddressPhone;
            }
        }
        if ('' !== $shippingAddress->phone_mobile) {
            $shippingAddressPhoneMobile = '+33' . substr(Tools::replaceAccentedChars($shippingAddress->phone_mobile), 1);
            if ('REVOLVINGPOS' === $paymentMean) {
                $billingAddressPhoneMobile = '+49' . substr(Tools::replaceAccentedChars($shippingAddress->phone_mobile), 1);
                if('+49666666666' === $billingAddressPhoneMobile) {
                    $billingAddressPhoneMobile = $billingAddressPhone;
                }
            }
            if('+33666666666' === $billingAddressPhoneMobile) {
                $billingAddressPhoneMobile = $billingAddressPhone;
            }
        }

        $sku = '0';
        if (isset($products[0]['ean13']) && '' !== $products[0]['ean13']) {
            $sku = (string)$products[0]['ean13'];
        }

        $secure_key = Context::getContext()->customer->secure_key;

        $datas = [
            'amount' => $amount,
            'customerId' => "" . $id_customer . "",
            'normalReturnUrl' => $context->link->getModuleLink('societegeneralepayment', 'confirmation'), //$returnUrl . 'module/societegeneralepayment/confirmation',
            'shoppingCartDetail' => [
                'mainProduct' => Tools::replaceAccentedChars($products[0]['name']),
                'shoppingCartTotalAmount' => (string)$amount,
                'shoppingCartTotalQuantity' => (string)$totalQty,
                'SKU' => $sku,
                'shoppingCartItemList' => [
                    'productName' => Tools::replaceAccentedChars((string)$products[0]['name']),
                    'productUnitAmount' => (string)$products[0]['price'],
                    'productQuantity' => (string)$products[0]['quantity'],
                    'productDescription' => strip_tags(Tools::replaceAccentedChars((string)$products[0]['description_short'])),
                ]
            ],
            'customerAddress' => [
                'city' => Tools::replaceAccentedChars($billingAddress->city),
                'street' => Tools::replaceAccentedChars($billingAddress->address1 . ' ' . $billingAddress->address2),
                'zipCode' => Tools::replaceAccentedChars($billingAddress->postcode),
                'country' => Tools::replaceAccentedChars($billingCountry->iso_code),
            ],
            'billingAddress' => [
                'city' => Tools::replaceAccentedChars($billingAddress->city),
                'street' => Tools::replaceAccentedChars($billingAddress->address1 . ' ' . $billingAddress->address2),
                'zipCode' => Tools::replaceAccentedChars($billingAddress->postcode),
                'country' => Tools::replaceAccentedChars($billingCountry->iso_code),
                'company' => Tools::replaceAccentedChars($billingAddress->company),
            ],
            'deliveryAddress' => [
                'city' => Tools::replaceAccentedChars($shippingAddress->city),
                'street' => Tools::replaceAccentedChars($shippingAddress->address1 . ' ' . $shippingAddress->address2),
                'zipCode' => Tools::replaceAccentedChars($shippingAddress->postcode),
                'country' => Tools::replaceAccentedChars($shippingCountry->iso_code),
                'company' => Tools::replaceAccentedChars($shippingAddress->company),
            ],
            'customerContact' => [
                'title' => '' . $civilityName . '',
                'legalId' => '',
                'email' => Tools::replaceAccentedChars($customer->email),
                'lastName' => Tools::replaceAccentedChars($billingAddress->lastname),
                'firstName' => Tools::replaceAccentedChars($billingAddress->firstname),
                'mobile' => $billingAddressPhone,
                'phone' => $billingAddressPhoneMobile,
            ],
            'billingContact' => [
                'legalId' => '',
                'email' => Tools::replaceAccentedChars($customer->email),
                'lastName' => Tools::replaceAccentedChars($billingAddress->lastname),
                'firstName' => Tools::replaceAccentedChars($billingAddress->firstname),
                'mobile' => $billingAddressPhoneMobile,
                'phone' => $billingAddressPhone,
            ],
            'deliveryContact' => [
                'legalId' => '',
                'email' => Tools::replaceAccentedChars($customer->email),
                'lastName' => Tools::replaceAccentedChars($shippingAddress->lastname),
                'firstName' => Tools::replaceAccentedChars($shippingAddress->firstname),
                'mobile' => $shippingAddressPhoneMobile,
                'phone' => $shippingAddressPhone,
            ],
            'orderId' => time() ."-". $cart->id,
            'paymentMean' => $paymentMean,
        ];

        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->apiUrl . '/api/v1/customerApplications/do-initialize',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($datas),
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $bearer,
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        if ('REVOLVINGPOS' === $paymentMean) {
            $language = Context::getContext()->language;
            Tools::redirect(str_replace('de-DE', $language->locale, $response));
        } else {
            echo $response;
        }

        curl_close($curl);
        die;
    }
}
