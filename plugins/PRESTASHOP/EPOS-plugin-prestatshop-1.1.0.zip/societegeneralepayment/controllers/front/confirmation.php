<?php

/**
 * 2022 Websource
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    Websource <jonathan@websource.fr>
 * @copyright 2022 Websource
 */
class SocietegeneralepaymentConfirmationModuleFrontController extends ModuleFrontController
{
    protected $apiUrl;

    public function __construct()
    {
        $this->apiUrl = 'https://apimgm-socgenepos-uat.azure-api.net';
        if ('1' === Configuration::get('SOCIETEGENERALEPAYMENT_MODE')) {
            $this->apiUrl = 'https://apimgm-socgenepos-prod.azure-api.net';
        }
        parent::__construct();
    }

    public function postProcess()
    {
        $bearer = $this->context->cookie->__get('sg_access_token');
        $token_expires = $this->context->cookie->__get('sg_access_token_time');

        if (false === $token_expires || time() > (int)$token_expires || null === $bearer) {
            $this->context->cookie->__set('sg_access_token', null);
            $this->context->cookie->__set('sg_access_token_time', null);

            $bearer = $this->context->cookie->__get('sg_access_token');
            $token_expires = $this->context->cookie->__get('sg_access_token_time');

            if (false == $bearer || time() > (int)$token_expires) {
                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => 'https://sso.sgmarkets.com/sgconnect/oauth2/access_token?grant_type=client_credentials&scope=openid',
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/x-www-form-urlencoded',
                        'Authorization: Basic Nzk3ZDI0ZjQtNmZmMi00MmMwLTg5ZjMtMDFhMjk4OWEwYWU5OjNsMDRoYWNjNDRnOGtiZDNlaDY0ZmxkbWcxOWU=',
                    ),
                ));

                $response = json_decode(curl_exec($curl));

                curl_close($curl);

                $bearer = $response->access_token;
                $token_expires = time() + $response->expires_in;
                $this->context->cookie->__set('sg_access_token', $response->access_token);
                $this->context->cookie->__set('sg_access_token_time', $token_expires);
                $this->context->cookie->setExpire(time() + $response->expires_in);
                $this->context->cookie->write();
            }

            if (false === $token_expires || time() > (int)$token_expires || null === $bearer) {
                Tools::redirect('index.php?controller=cart&action=show');
            }
        }

        $result = explode("|", Tools::getValue('Data'));
        $datas = [];
        foreach ($result as $data) {
            $explode = explode('=', $data);
            $datas[$explode[0]] = $explode[1];
        }

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $this->apiUrl . '/api/v1/customerApplications/do-search',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode(['orderId' => $datas['orderId']]),
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $bearer,
                'Content-Type: application/json'
            ),
        ));

        $response = json_decode(curl_exec($curl))[0];

        curl_close($curl);

        $returnDatas = explode('-', $response->orderId);

        $cart_id = $returnDatas[1];
        $secure_key = Context::getContext()->customer->secure_key;

        $cart = new Cart((int)$cart_id);
        $customer = new Customer((int)$cart->id_customer);

        /**
         * Since it's an example we are validating the order right here,
         * You should not do it this way in your own module.
         */
        $payment_status = Configuration::get('PS_OS_PAYMENT'); // Default value for a payment that succeed.
        $message = null; // You can add a comment directly into the order so the merchant will see it in the BO.

        /**
         * Converting cart into a valid order
         */
        $module_name = $this->module->displayName;
        $currency_id = (int)Context::getContext()->currency->id;

        /**
         * If the order has been validated we try to retrieve it
         */
        $order_id = Order::getOrderByCartId((int)$cart->id);
        $i = 0;

        while('INITIALIZED' === $response->status && $i <= 10) {
            sleep(5);

            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => $this->apiUrl . '/api/v1/customerApplications/do-search',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode(['orderId' => $datas['orderId']]),
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer ' . $bearer,
                    'Content-Type: application/json'
                ),
            ));

            $response = json_decode(curl_exec($curl))[0];

            curl_close($curl);

            $returnDatas = explode('-', $response->orderId);

            $cart_id = $returnDatas[1];
            $i++;
        }

        if ($secure_key == $customer->secure_key && in_array($response->status, ['ACCEPTED', 'INITIATED', 'PRE-ACCEPTED', 'KYC-SUCCESSFUL'])) {
            /**
             * The order has been placed so we redirect the customer on the confirmation page.
             */
            $module_id = $this->module->id;
            $this->module->validateOrder($cart_id, $payment_status, $cart->getOrderTotal(), $module_name, $message, array(), $currency_id, false, $secure_key);
            Tools::redirect('index.php?controller=order-confirmation&id_cart=' . $cart_id . '&id_module=' . $module_id . '&id_order=' . $order_id . '&key=' . $secure_key);
        } else {

            if ($response->status === 'REJECTED' || $response->status === 'ABORTED') {
                $this->errors[] = $this->module->l('Paiement refusé.');
            } elseif ($response->status === 'CANCELLED') {
                $this->errors[] = $this->module->l('Paiement annulé.');
            } else {
                $this->errors[] = $this->module->l('An error occured. Please contact the merchant to have more informations');
            }

            $this->context->smarty->assign('errors', $this->errors);
            $this->setTemplate('module:societegeneralepayment/views/templates/front/error.tpl');
        }
    }
}
